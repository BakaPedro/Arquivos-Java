
//import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Conteudo {
	private String nome;
	private int temp;
	private int ep;
	private Date data;
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTemp() {
		return temp;
	}

	public void setTemp(int temp) {
		this.temp = temp;
	}

	public int getEp() {
		return ep;
	}

	public void setEp(int ep) {
		this.ep = ep;
	}

	public Date getData() {
		return data;
	}
	public String data() {
		return sdf.format(data);
	}
	public void setData(Date data) {
		this.data = data;
	}
	public String toString() {
		return this.getNome() +"\n"+ this.getTemp() +"\n"+ this.getEp() +"\n"+sdf.format(this.getData())+"\n";
	}
}
