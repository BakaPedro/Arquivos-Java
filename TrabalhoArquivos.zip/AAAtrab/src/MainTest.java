import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

//código para salvar animes vistos em um txt

public class MainTest {

	static Scanner scn = new Scanner(System.in);

	static File file = new File("C:\\Users\\T-GAMER\\Desktop\\Salvo"); // edite o caminho e mágica irá acontecer

	public static Conteudo conteudo() throws ParseException {
		Conteudo c = new Conteudo();
		System.out.println("Nome do anime:");
		String nome = scn.nextLine();
		c.setNome(nome);
		System.out.println("Quantidade de temporada:");
		int qnt = scn.nextInt();
		c.setTemp(qnt);
		System.out.println("Quantidade de episódio:");
		int qntep = scn.nextInt();
		c.setEp(qntep);
		scn.nextLine();
		System.out.println("Data que assistiu(dd/mm/aaaa):");
		Date data = new Date(scn.nextLine());
		c.setData(data);

		return c;
	}

	public static void menu() {
		System.out.println("Digite: ");
		System.out.println("[1] - Listar arquivos e pastas");
		System.out.println("[2] - Criar arquivos");
		System.out.println("[3] - Mostrar dados do arquivo");
		System.out.println("[4] - Adicionar dados no arquivo");
		System.out.println("[0] - Sair");
	}

	public static void main(String[] args) throws ParseException, IOException {

		if (!file.exists()) {
			System.out.println("Necessário cria uma pasta 'Salvo' em 'coloque seu caminho'? S ou N");
			String opcao = scn.nextLine();
			if (opcao.equals("S")) {
				System.out.println("Pasta 'Salvo' Criada");
				file.mkdir();
			} else {
				System.out.println("Saindo");
				return;
			}
		}
		int a = -1;
		do {
			menu();
			a = scn.nextInt();
			scn.nextLine();
			switch (a) {
			case 1:
				listarItens();
				break;
			case 2:
				criarArquivos();
				break;
			case 3:
				lerArquivo();
				break;
			case 4:
				escreverNoArquivo();
				break;
			case 0:
				break;
			default:
				System.out.println("Opção inválida.");
			}
		} while (a != 0);
	}

	private static void listarItens() {
		System.out.println("Arquivos");
		listarArquivos();
		System.out.println("Pasta");
		listarPasta();
	}

	private static void listarPasta() {
		File[] itens = file.listFiles();
		for (int i = 0; i < itens.length; i++) {
			if (itens[i].isDirectory()) {
				System.out.println("\t[" + i + "]" + itens[i].getName());
			}
		}
	}

	private static void listarArquivos() {
		File[] itens = file.listFiles();

		for (int i = 0; i < itens.length; i++) {
			if (itens[i].isFile()) {
				System.out.println("\t[" + i + "]" + itens[i].getName());
			}
		}
	}

	private static void criarArquivos() {
		System.out.println("Digite o nome do arquivo:");
		String nome = scn.nextLine();
		File arquivo = new File(file, nome);
		if (arquivo.exists()) {
			System.out.println("Arquivo já existe");
		} else {
			try {
				boolean result = arquivo.createNewFile();
				if (result) {
					System.out.println("Arquivo criado com sucesso");
				}
			} catch (Exception e) {
				System.out.println("Errou -" + e.getMessage());
			}
		}
	}

	private static void lerArquivo() {
		listarArquivos();
		ArrayList<Conteudo> aa = new ArrayList<Conteudo>();
		System.out.println("Qual arquivo deseja ler?");
		int opcao = scn.nextInt();
		scn.nextLine();
		File[] files = file.listFiles();
		File file = files[opcao];
		try {
			Scanner leitorArquivo = new Scanner(file);

			while (leitorArquivo.hasNextLine()) {

				Conteudo c = new Conteudo();
				c.setNome(leitorArquivo.nextLine());
				c.setTemp(leitorArquivo.nextInt());
				leitorArquivo.nextLine();
				c.setEp(leitorArquivo.nextInt());
				leitorArquivo.nextLine();
				Date data = new Date(leitorArquivo.nextLine());
				c.setData(data);
				aa.add(c);
			}
			for (Conteudo aaa : aa) {
				System.out.println("Nome: " + aaa.getNome());
				System.out.println("Temporadas: " + aaa.getTemp());
				System.out.println("Episódios: " + aaa.getEp());
				System.out.println("Data de visualização: " + aaa.data());
				System.out.println();
			}
			System.out.println("#FIM#");
		} catch (Exception e) {
			System.out.println("Deu erro pra ler - " + e.getMessage());
		}
	}

	private static void escreverNoArquivo() throws ParseException, IOException {
		listarArquivos();
		ArrayList<Conteudo> aa = new ArrayList<Conteudo>();
		System.out.println("Qual arquivo deseja escrever?");
		int opcao = scn.nextInt();
		scn.nextLine();
		aa.add(conteudo());
		File[] files = file.listFiles();
		File file = files[opcao];
		try {
			FileWriter fileWriter = new FileWriter(file, true);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			int i = 0;
			for (int a = 0; a < aa.size(); a++) {
				printWriter.println(aa.get(i).getNome());
				printWriter.println(aa.get(i).getTemp());
				printWriter.println(aa.get(i).getEp());
				printWriter.println(aa.get(i).data());
			}
			printWriter.flush();
			printWriter.close();
		} catch (FileNotFoundException e) {
			System.out.println("Erro: " + e.getMessage());
		}
	}
}
